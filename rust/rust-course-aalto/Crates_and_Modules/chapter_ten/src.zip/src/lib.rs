pub fn library_function() -> String {
    "📚📚📚".to_string()
}
